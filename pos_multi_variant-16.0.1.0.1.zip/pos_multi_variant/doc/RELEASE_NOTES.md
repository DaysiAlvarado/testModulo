## Module <pos_multi_variant>

#### 12.10.2023
#### Version 16.0.1.0.0
##### ADD
- Initial commit for POS Product Multi variant


#### 14.01.2025
#### Version 16.0.1.0.1
##### ADD
- Fixed issue related to the amount total in pos orders.